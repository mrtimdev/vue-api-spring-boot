<template>
  <div id="app">
    <CarComponent />
  </div>
</template>

<script setup lang="ts">
import CarComponent from './components/CarComponent.vue'
</script>
